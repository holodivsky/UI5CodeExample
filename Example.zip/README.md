Internal application for handling outdated CV
